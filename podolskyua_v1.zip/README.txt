Podolskyua v1

1. Open index.html in a browser.
2. Change the number in script.js:
const soldOut = 2147;
